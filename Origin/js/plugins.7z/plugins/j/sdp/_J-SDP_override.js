/*
 * @command Reset SDP
 * @text Reset Panel(s)
 * @desc Reset a panel for the player to level up by its key. Key must exist in the SDPs list above.
 * @arg actorId
 * @type actor
 * @desc The actor to modify the points of.
 * @arg keys
 * @type string[]
 * @desc The unique keys for the SDPs that will be reset.
 * 
 */


var J = J || {};
J.SDP.OR = {};

 PluginManager.registerCommand(J.SDP.Metadata.Name, "Reset SDP", args =>
 {
   let {actorId,keys} = args;
   keys = JSON.parse(keys);
   actorId = parseInt(actorId);
   keys.forEach(key =>
   {
     $gameSystem.resetSdp(actorId,key);
   });
 });
 
/**
 * Resets a SDP by its key.
 * @param {string} key The key of the SDP to unlock.
 */

 Game_Actor.prototype.resetSdpRankByKey = function(key)
 {
   // don't try to search if there are no rankings at this time.
   if (!this._j._sdp._ranks.length) return;
   this._j._sdp._ranks.find(panelRanking => panelRanking.key === key).currentRank = 0;
 };
 Game_System.prototype.resetSdp = function(actorId,key)
{
    const actor = $gameActors.actor(actorId);
  const panel = this.getSdp(key);
  if (panel)
  {
    actor.resetSdpRankByKey(key);
    //   const panelRanking = new PanelRanking(key, this.actorId());
    //   panelRanking.currentRank = 0;
    //   this._j._sdp._ranks.push(panelRanking);
  
      //if(panel.)
    //panel.unlock();
  }
  else
  {
    console.error(`The SDP key of ${key} was not found in the list of panels.`);
  }
};